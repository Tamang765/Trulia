/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,jsx,scss}"],
  theme: {
    extend: {},
  },
  plugins: [],
}