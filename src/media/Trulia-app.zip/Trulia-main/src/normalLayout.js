import React from 'react'

const normalLayout = (children) => {
  return (
    <>
    {children}
    </>
  )
}

export default normalLayout