const Newlist = [
    {
      id: "1",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-1",
      images: [require("../../media/bgone.jpg")]
    },
    {
      id: "2",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-2",
      images: [require("../../media/smone.jpg")]
    },
    {
      id: "3",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-3"
    },
    {
      id: "4",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-4"
  
  
    },
    {
      id: "5",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-5"
  
    },
    {
      id: "6",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-6"
  
    },
    {
      id: "7",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-7"
  
    },
    {
      id: "8",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-8"
  
    },
    {
      id: "9",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-9"
  
    },
    {
      id: "10",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-10"
  
    },
    {
      id: "11",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-11"
  
    },
    {
      id: "12",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-12"
  
    },
    {
      id: "13",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-13"
  
    },
    {
      id: "14",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-14"
  
    },
    {
      id: "15",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-15"
  
    },
    {
      id: "16",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      category:"item-16"
  
    },
  ];
  export default Newlist;