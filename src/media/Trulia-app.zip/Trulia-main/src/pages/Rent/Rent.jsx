import React from 'react'

const Rent = () => {
  return (
    <div>This is rent component</div>
  )
}

export default Rent