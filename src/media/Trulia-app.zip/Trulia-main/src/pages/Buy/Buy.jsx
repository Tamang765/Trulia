import React from 'react'

const Buy = () => {
  return (
    <div>This is buy component</div>
  )
}

export default Buy