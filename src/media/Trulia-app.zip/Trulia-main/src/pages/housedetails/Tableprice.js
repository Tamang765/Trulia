const Tableprice=[{
    id:"1",
    date:"01/09/2023",
    price:"$123k",
    event:"PriceChange",
    source:"GAMLS",
    pricechange:"$123K(-2%)"
},
{
    id:"2",
    date:"01/04/2023",
    price:"$32K",
    event:"Listed For Sale",
    source:"GAMLS",
    pricechange:"$123K(2%)"
}
,{
    id:"3",
    date:"12/03/2022",
    price:"$972K",
    event:"sold out",
    source:"GAMLS",
    pricechange:"$13K(8%)"
}
]
export default Tableprice;