const CardData=[{
    id:"1",
    username:"Hero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
},
{
    id:"2",
    username:"zero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
},
{
    id:"3",
    username:"Hero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
},
{
    id:"4",
    username:"Hero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
},
{
    id:"5",
    username:"Hero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
},
{
    id:"6",
    username:"Hero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
},
{
    id:"7",
    username:"Hero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
},
{
    id:"8",
    username:"Hero",
    time:"2 year",
    desc:"Events in the park and Midtown area. Lots of fun breweries and restaurants. Concerts close by and sense of community even for a big city.",
    likes:"1"
}
]
export default CardData;