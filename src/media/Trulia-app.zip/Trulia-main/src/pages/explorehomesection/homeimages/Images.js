const ImageList = [
    {
      id: "1",
      posted: "NEW-58 min ago",
      price: "$23456",
      bed: "3bd",
      lock: "3ba",
      sqft: "123 sqft",
      place: "2914 lenox Rd NE Atlanta, GA 30324 ",
      location: "Engel & vokers",
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/smone.jpg"),require("../../../media/smone.jpg")],
      images: [require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
      title: "Bed",
      category: "item-1",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/BuyAHome.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-2",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-3",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-4",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-5",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-6",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-7",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-8",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-9",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-10",
    },    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-11",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-12",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-13",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-14",
    },    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg")],
        title: "Bed",
        category: "item-15",
    },
    {
      activethreeimg:[require("../../../media/bgone.jpg"), require("../../../media/bgone.jpg")],
        images: [require("../../../media/discover.jpg"), require("../../../media/bgone.jpg"),require("../../../media/seeneb.JPG")],
        title: "Bed",
        category: "item-16",
    },
    
  ];
  
  export default ImageList;